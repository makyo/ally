# Why be a fox?

A question as old as time.
