# Afterword

As you can see, it's *totally* worth it to be a fox.
