# The pros of being a fox

* Soft
* Fluffy
* Fantastic tail
