# The cons of being a fox

* No thumbs
* ...
* That's literally it
